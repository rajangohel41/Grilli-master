import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPage extends JFrame {
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginPage () {
        // Create the main frame
        frame = new JFrame("Login Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 300);

        // Create a panel to hold the username and password fields
       

        //layout
        frame.setLayout(null);
        GridBagConstraints constraints = new GridBagConstraints();
        
        //textfilds
        JLabel username = new JLabel("Username:");
        frame.add(username);
        username.setBounds(100, 100,100, 10);       
        usernameField = new JTextField(10);        
        frame.add(usernameField);
        usernameField.setBounds(200, 98,200, 20);

        JLabel userpassword = new JLabel("userpassword:");
        frame.add(userpassword);
        userpassword.setBounds(100, 130,100, 10); 
        passwordField = new JPasswordField(10);
        frame.add(passwordField);
        passwordField.setBounds(200, 127,200, 20);
        

        // Create a panel to hold the login button
        
        JButton loginButton = new JButton("Login");
        frame.add(loginButton);
        loginButton.setBounds(200, 170,200, 30);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                // Validate the username and password here
                // ...
                JOptionPane.showMessageDialog(frame, "Welcome, " + username + "!");
                new Grilli();
            }
        });
        

        // Make the frame visible
        frame.setVisible(true);
    }    
    public static void main(String[] args) {
        //LoginPage login = new LoginPage();
        new LoginPage();
}}