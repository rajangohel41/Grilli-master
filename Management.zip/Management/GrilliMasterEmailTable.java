import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class GrilliMasterEmailTable {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private Connection conn = null;
    private Statement stmt = null;
    private ResultSet resultSet = null;

    public GrilliMasterEmailTable() {
        // Create the main frame
        frame = new JFrame("Grilli Master Email Table");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 300);

        // Create a table model
        model = new DefaultTableModel();
        model.addColumn("Email");

        // Create a table
        table = new JTable(model);
        table.setDefaultEditor(Object.class, new DefaultCellEditor(new JTextField()));

        // Create a scroll pane for the table
        JScrollPane scrollPane = new JScrollPane(table);

        // Connect to the database
       

        try {
           // Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/grilli-master", "username", "password");
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery("SELECT email FROM subscribe");

            // Add data to the table model
            while (resultSet.next()) {
                model.addRow(new Object[]{resultSet.getString("email")});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet!= null) {
                    resultSet.close();
                }
                if (stmt!= null) {
                    stmt.close();
                }
                if (conn!= null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Add buttons to add, edit, and delete rows
        JButton addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                model.addRow(new Object[]{""});
            }
        });

        JButton editButton = new JButton("Edit");
        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow!= -1) {
                    String email = (String) table.getValueAt(selectedRow, 0);
                    // Update the database with the new email value
                    try {
                        stmt = conn.createStatement();
                        stmt.executeUpdate("UPDATE email SET email = '" + email + "' WHERE email = '" + email + "'");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow!= -1) {
                    String email = (String) table.getValueAt(selectedRow, 0);
                    // Delete the row from the database
                    try {
                        stmt = conn.createStatement();
                        stmt.executeUpdate("DELETE FROM email WHERE email = '" + email + "'");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                    model.removeRow(selectedRow);
                }
            }
        });

        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Add the scroll pane and the button panel to the frame
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Make the frame visible
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new GrilliMasterEmailTable();
    }
}