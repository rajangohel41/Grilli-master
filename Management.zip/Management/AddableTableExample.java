import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DatabaseTableExample {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;

    public DatabaseTableExample() {
        // Create the main frame
        frame = new JFrame("Database Table Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 300);

        // Connect to the database
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/grilli-master", "username", "password");
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT email FROM subscribe");

            // Create a table model
            model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            model.addColumn("Email");
            while (resultSet.next()) {
                model.addRow(new Object[]{resultSet.getString("email")});
            }

            // Create a table
            table = new JTable(model);

            // Create a scroll pane for the table
            JScrollPane scrollPane = new JScrollPane(table);

            // Add the scroll pane to the frame
            frame.add(scrollPane, BorderLayout.CENTER);

            // Make the frame visible
            frame.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet!= null) {
                    resultSet.close();
                }
                if (statement!= null) {
                    statement.close();
                }
                if (connection!= null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new DatabaseTableExample();
    }
}