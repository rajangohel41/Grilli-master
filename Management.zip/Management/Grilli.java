import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import java.sql.*;


public class Grilli {
    //Frame
    private JFrame frame;   
    //TextFields
    private JTextField usernameField;
    private JPasswordField passwordField; 
    //Panels    
    private JPanel cardPanel;   
    private JPanel btnpanel;
    private JPanel buttonPanel;
    //Buttons
    private JButton subscribe;
    private JButton onlineOrder;
    private JButton payment;    
    private JButton onlineReservation;
    private JButton feedback;
    private JButton signUp;
    private JButton loginButton;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    //Layouts
    private CardLayout cardLayout; 
    //Cards
    private JPanel card1;
    private JPanel card2;
    private JPanel card3;
    private JPanel card4;
    private JPanel card5;
    private JPanel card6;
    private JPanel card7;

    //Labels
    private JLabel username;
    private JLabel userpassword;
    //Tables
    private DefaultTableModel subscribeModel;
    private JTable subscribetable;
    //ScrolPanes
    private JScrollPane subscribeScrollPane;

    //Database
    private Connection conn = null;
    private Statement stmt = null;
    private ResultSet resultSet = null;

    public Grilli() {
        
        // ----Create the main frame----//
        frame = new JFrame("Grillis Management");        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 500);
        frame.setLayout(new BorderLayout());


        // ----Create a panel to hold the components----//

        // btnpanel--//
        btnpanel = new JPanel();
        btnpanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        btnpanel.setLayout(new GridLayout(6, 1,2,2));

        // cardpanel to hold cards--//
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));

        //card-1 for login --//
        card1 = new JPanel(null);

        //card-2 for subscribe --//
        card2 = new JPanel(new BorderLayout());

        //card-3 for publish --//


        // login --//
        username = new JLabel("Username:");
        card1.add(username);
        username.setBounds(100, 100,100, 10);       
        usernameField = new JTextField(10);        
        card1.add(usernameField);
        usernameField.setBounds(200, 98,200, 20);

        userpassword = new JLabel("userpassword:");
        card1.add(userpassword);
        userpassword.setBounds(100, 130,100, 10); 
        passwordField = new JPasswordField(10);
        card1.add(passwordField);
        passwordField.setBounds(200, 127,200, 20);

        loginButton = new JButton("Login");
        card1.add(loginButton);
        loginButton.setBounds(200, 170,200, 30);  
        
        // subscribe--//
        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
       
        // ----Add a button to the panel----//
        subscribe = new JButton("Subscribe Data");
        subscribe.setEnabled(false);
        btnpanel.add(subscribe);

        onlineOrder = new JButton("Online Order Data");
        onlineOrder.setEnabled(false);
        btnpanel.add(onlineOrder);

        payment = new JButton("Payment Data");
        payment.setEnabled(false);
        btnpanel.add(payment);

        onlineReservation = new JButton("Online Reservation Data");
        onlineReservation.setEnabled(false);
        btnpanel.add(onlineReservation);

        feedback = new JButton("Feedback Data");
        feedback.setEnabled(false);
        btnpanel.add(feedback);

        signUp = new JButton("Open New Window");
        signUp.setEnabled(false);
        btnpanel.add(signUp);        


        // ----Create Table Models----//
        subscribeModel = new DefaultTableModel(new Object[]{"Column 1", "Column 2"}, 0);

        // ----Create a table----//
        subscribetable = new JTable(subscribeModel);

        // ----Create a scroll pane for the table----//
        subscribeScrollPane = new JScrollPane(subscribetable);

        // ----ButtonPanel----//
        buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

       
        // ----Add the panel to the frame----//
        frame.add(btnpanel , BorderLayout.WEST);  
        frame.add(cardPanel, BorderLayout.CENTER);  
        frame.setVisible(true);

        // ----Add cards to cardPanel----//
        cardPanel.add(card1, "Log in");
        cardPanel.add(card2, "subscribe");


        // ----Add to card2----//
        card2.add(subscribeScrollPane, BorderLayout.NORTH);
        card2.add(buttonPanel, BorderLayout.SOUTH);

       // ----Showing panels----//
        cardLayout.show(cardPanel, "Log in");

        // ----Add an action listener to the button----//

        // loginBution--//
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JOptionPane.showMessageDialog(card1 , "Welcome, " + username + "!");
                
                subscribe.setEnabled(true);
                payment.setEnabled(true);
                onlineOrder.setEnabled(true);
                onlineReservation.setEnabled(true);
                signUp.setEnabled(true);
                feedback.setEnabled(true);             
                
                
            }
        });

        // addButton--//
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                subscribeModel.addRow(new Object[]{"", ""});
            }
        });

        // editButton--//
        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = subscribetable.getSelectedRow();
                if (selectedRow!= -1) {
                    subscribeModel.setValueAt("Edited Value", selectedRow, 0);
                }
            }
        });

        // deletButton--//
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = subscribetable.getSelectedRow();
                if (selectedRow!= -1) {
                    subscribeModel.removeRow(selectedRow);
                }
            }
        });

        // subscribeButton--//
        subscribe.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                cardLayout.show(cardPanel, "subscribe");              
                                               
            }
        });


    }

    public static void main(String[] args) {
        //LoginPage login = new LoginPage();
        new Grilli();
    }
}